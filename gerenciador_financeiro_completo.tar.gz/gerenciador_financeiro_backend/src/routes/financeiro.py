from flask import Blueprint, request, jsonify
from src.models.financeiro import db, Pessoa, Transacao
from datetime import datetime
import time

financeiro_bp = Blueprint('financeiro', __name__)

# Middleware para CORS
@financeiro_bp.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    return response

@financeiro_bp.route('/pessoas', methods=['GET'])
def get_pessoas():
    """Retorna todas as pessoas cadastradas"""
    try:
        pessoas = Pessoa.query.all()
        return jsonify({
            'success': True,
            'data': {pessoa.nome: pessoa.to_dict() for pessoa in pessoas}
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@financeiro_bp.route('/transacoes', methods=['GET'])
def get_transacoes():
    """Retorna todas as transações"""
    try:
        transacoes = Transacao.query.order_by(Transacao.data.desc()).all()
        return jsonify({
            'success': True,
            'data': [transacao.to_dict() for transacao in transacoes]
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@financeiro_bp.route('/transacao', methods=['POST'])
def criar_transacao():
    """Cria uma nova transação"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'success': False, 'error': 'Dados não fornecidos'}), 400
        
        nome_pessoa = data.get('pessoa', '').strip()
        valor = data.get('valor')
        tipo = data.get('tipo')
        descricao = data.get('descricao', '').strip()
        
        if not nome_pessoa:
            return jsonify({'success': False, 'error': 'Nome da pessoa é obrigatório'}), 400
        
        if valor is None or valor == 0:
            return jsonify({'success': False, 'error': 'Valor deve ser diferente de zero'}), 400
        
        if tipo not in ['divida', 'pagamento']:
            return jsonify({'success': False, 'error': 'Tipo deve ser "divida" ou "pagamento"'}), 400
        
        # Buscar ou criar pessoa
        pessoa = Pessoa.query.filter_by(nome=nome_pessoa).first()
        if not pessoa:
            pessoa = Pessoa(nome=nome_pessoa)
            db.session.add(pessoa)
        
        # Criar transação
        transacao = Transacao(
            pessoa_nome=nome_pessoa,
            valor=abs(valor),
            tipo=tipo,
            descricao=descricao,
            timestamp=int(time.time() * 1000)
        )
        
        db.session.add(transacao)
        
        # Atualizar saldo da pessoa
        atualizar_saldo_pessoa(pessoa)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': {
                'transacao': transacao.to_dict(),
                'pessoa': pessoa.to_dict()
            }
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@financeiro_bp.route('/transacao/<int:transacao_id>', methods=['PUT'])
def atualizar_transacao(transacao_id):
    """Atualiza uma transação existente"""
    try:
        transacao = Transacao.query.get_or_404(transacao_id)
        data = request.get_json()
        
        if not data:
            return jsonify({'success': False, 'error': 'Dados não fornecidos'}), 400
        
        valor = data.get('valor')
        tipo = data.get('tipo')
        descricao = data.get('descricao', '').strip()
        
        if valor is None or valor == 0:
            return jsonify({'success': False, 'error': 'Valor deve ser diferente de zero'}), 400
        
        if tipo not in ['divida', 'pagamento']:
            return jsonify({'success': False, 'error': 'Tipo deve ser "divida" ou "pagamento"'}), 400
        
        # Atualizar transação
        transacao.valor = abs(valor)
        transacao.tipo = tipo
        transacao.descricao = descricao
        
        # Atualizar saldo da pessoa
        pessoa = Pessoa.query.filter_by(nome=transacao.pessoa_nome).first()
        if pessoa:
            atualizar_saldo_pessoa(pessoa)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': {
                'transacao': transacao.to_dict(),
                'pessoa': pessoa.to_dict() if pessoa else None
            }
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@financeiro_bp.route('/transacao/<int:transacao_id>', methods=['DELETE'])
def excluir_transacao(transacao_id):
    """Exclui uma transação"""
    try:
        transacao = Transacao.query.get_or_404(transacao_id)
        nome_pessoa = transacao.pessoa_nome
        
        db.session.delete(transacao)
        
        # Atualizar saldo da pessoa ou excluir se não tiver mais transações
        pessoa = Pessoa.query.filter_by(nome=nome_pessoa).first()
        if pessoa:
            transacoes_restantes = Transacao.query.filter_by(pessoa_nome=nome_pessoa).count()
            if transacoes_restantes == 0:
                db.session.delete(pessoa)
            else:
                atualizar_saldo_pessoa(pessoa)
        
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Transação excluída com sucesso'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@financeiro_bp.route('/pessoa/<nome>/quitar', methods=['POST'])
def quitar_pessoa(nome):
    """Quita uma pessoa (zera o saldo)"""
    try:
        pessoa = Pessoa.query.filter_by(nome=nome).first_or_404()
        
        if pessoa.saldo == 0:
            return jsonify({'success': False, 'error': 'Pessoa já está quitada'}), 400
        
        # Criar transação de quitação
        valor_quitacao = abs(pessoa.saldo)
        tipo_quitacao = 'pagamento' if pessoa.saldo > 0 else 'divida'
        
        transacao = Transacao(
            pessoa_nome=nome,
            valor=valor_quitacao,
            tipo=tipo_quitacao,
            descricao='Quitação automática',
            timestamp=int(time.time() * 1000)
        )
        
        db.session.add(transacao)
        
        # Atualizar saldo da pessoa
        atualizar_saldo_pessoa(pessoa)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': {
                'transacao': transacao.to_dict(),
                'pessoa': pessoa.to_dict()
            }
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@financeiro_bp.route('/pessoa/<nome>', methods=['DELETE'])
def excluir_pessoa(nome):
    """Exclui uma pessoa e todas suas transações"""
    try:
        pessoa = Pessoa.query.filter_by(nome=nome).first_or_404()
        
        # Excluir todas as transações da pessoa (cascade já configurado)
        db.session.delete(pessoa)
        db.session.commit()
        
        return jsonify({'success': True, 'message': f'Pessoa {nome} e todas suas transações foram excluídas'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@financeiro_bp.route('/dados', methods=['GET'])
def get_todos_dados():
    """Retorna todos os dados (pessoas e transações) para compatibilidade com o frontend"""
    try:
        pessoas = Pessoa.query.all()
        transacoes = Transacao.query.order_by(Transacao.data.desc()).all()
        
        # Calcular próximo ID
        next_id = 1
        if transacoes:
            next_id = max(t.id for t in transacoes) + 1
        
        return jsonify({
            'success': True,
            'data': {
                'pessoas': {pessoa.nome: pessoa.to_dict() for pessoa in pessoas},
                'transacoes': [transacao.to_dict() for transacao in transacoes],
                'nextId': next_id
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@financeiro_bp.route('/dados', methods=['POST'])
def salvar_todos_dados():
    """Salva todos os dados (para compatibilidade com backup/restore)"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'success': False, 'error': 'Dados não fornecidos'}), 400
        
        pessoas_data = data.get('pessoas', {})
        transacoes_data = data.get('transacoes', [])
        
        # Limpar dados existentes
        Transacao.query.delete()
        Pessoa.query.delete()
        
        # Recriar pessoas
        for nome, pessoa_info in pessoas_data.items():
            pessoa = Pessoa(
                nome=nome,
                saldo=pessoa_info.get('saldo', 0),
                total_dividas=pessoa_info.get('totalDividas', 0),
                total_pagamentos=pessoa_info.get('totalPagamentos', 0)
            )
            db.session.add(pessoa)
        
        # Recriar transações
        for transacao_data in transacoes_data:
            transacao = Transacao(
                id=transacao_data.get('id'),
                pessoa_nome=transacao_data.get('pessoa'),
                valor=transacao_data.get('valor'),
                tipo=transacao_data.get('tipo'),
                descricao=transacao_data.get('descricao', ''),
                data=datetime.fromisoformat(transacao_data.get('data').replace('Z', '+00:00')) if transacao_data.get('data') else datetime.utcnow(),
                timestamp=transacao_data.get('timestamp', int(time.time() * 1000))
            )
            db.session.add(transacao)
        
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Dados restaurados com sucesso'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@financeiro_bp.route('/limpar', methods=['DELETE'])
def limpar_todos_dados():
    """Limpa todos os dados do banco"""
    try:
        Transacao.query.delete()
        Pessoa.query.delete()
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Todos os dados foram limpos'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

def atualizar_saldo_pessoa(pessoa):
    """Função auxiliar para atualizar o saldo de uma pessoa"""
    transacoes = Transacao.query.filter_by(pessoa_nome=pessoa.nome).all()
    
    total_dividas = sum(t.valor for t in transacoes if t.tipo == 'divida')
    total_pagamentos = sum(t.valor for t in transacoes if t.tipo == 'pagamento')
    
    pessoa.saldo = total_dividas - total_pagamentos
    pessoa.total_dividas = total_dividas
    pessoa.total_pagamentos = total_pagamentos
    pessoa.ultima_transacao = datetime.utcnow()
    pessoa.updated_at = datetime.utcnow()

